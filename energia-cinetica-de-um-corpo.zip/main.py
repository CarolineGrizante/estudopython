#Exercício de Energia Cinética:

"Ec=0.5*m*V²"

print("O velocímetro de um automóvel registra 108 km/h.Sabendo que a massa do automóvel é 700 kg,determine a energia cinética.")

m=int("700")
V=int("108")

E=(V**2)
Ec=0.5*m*E

print("A energia cinética do automóvel é de:",Ec, "J")
