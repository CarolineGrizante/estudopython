#Exercício sobre Período de um planeta:

print("Um novo planeta foi encontrado em um galáxia próxima e os cientistas querem definir qual é o seu período de rotação. Determine esse período sabendo que o raio tem 120km de raio. ")
"T²= K.r³"
K=float(0.12)
r=input("Defina o raio:")
r=int(r)

T1=(r**3)
T2= T1*K
T= T2**0.5

print("O período do planeta é",round(T,3),"u.a.")
