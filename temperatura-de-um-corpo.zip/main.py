#Exercício sobre temperatura:

"Tc/5= (Tf-32)/9 ou 9Tc= (5Tf-160)"

print("Um cientista está fazendo um experimento com um líquido a 85 C°. Para que ele dê certo as medidas devem ser todas no Sistema Internacional. Ajude o cientista a descobrir qual o valor da temperatura do líquido em farenheight.")

Tc=input("Coloque a temperatura do líquido em Celsius:")
Tc=float(Tc)

T1= 9*Tc
Tf= (160+T1)/5

print("A temperatura será de",Tf,"farenheight.")
