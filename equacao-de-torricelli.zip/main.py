#Exercício de Torricelli
"V²=Vo²+2.a.S"
print("Um carro com aceleração de 8.2 m/s² percorre um trajeto de 600m. Descubra qual sua velocidade final adotando uma velocidade inicial qualquer")

Vo= input("Defina a velocidade:")
Vo= float(Vo)
a= float("8.2")
S= float("600")

V1=(Vo**2) + (2*a*S)
V= V1**0.5

print("A velocidade final será de:",round(V,3),"m/s².")
